steps to Berrilum's RAT software to enhance your Beaming experience!

1. download and extract the file

2. open berrilum RAT 

3. sign up

4 enjoy!